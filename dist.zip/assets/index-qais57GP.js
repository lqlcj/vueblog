import{i as M,_ as N,r as k,b as I,d as m,c as p,e as n,j as y,F as P,k as w,t as v,u as j,o as _,n as x}from"./index-Jz6l4OgK.js";import{f as D}from"./index-BHH6zp8u.js";const C=`---\r
title: "Notion笔记神器"\r
date: "2025-11-28"\r
cover: "/images/01.jpg"\r
ratio: 0.75\r
---\r
今天给大家安利一个超级强大的All-in-One笔记软件——Notion！🔥\r
	\r
🌟 为什么Notion被称为"最后一款笔记软件"？\r
	\r
因为它真的什么都能做！\r
	\r
💡 Notion = 笔记软件 + 任务管理 + 数据库 + 个人博客 + 团队协作 + 更多！\r
	\r
🎯 核心功能亮点：\r
	\r
1️⃣ 块状编辑系统\r
所有内容都是可拖拽的块，像搭乐高一样自由排版！\r
文字、图片、视频、代码、表格、待办清单...想怎么组合就怎么组合\r
	\r
2️⃣ 强大的数据库功能\r
支持5种视图：表格、看板、日历、画廊、列表\r
同一份数据，不同视图展示，满足各种场景需求\r
	\r
3️⃣ 全平台同步\r
Web、Windows、Mac、iOS、Android全平台支持\r
数据实时同步，随时随地访问\r
	\r
4️⃣ 团队协作神器\r
多人实时协作，权限精细控制\r
评论、@功能、历史版本管理\r
	\r
5️⃣ 丰富的模板库\r
数千个专业模板，一键套用\r
读书笔记、项目管理、旅行计划、OKR管理...应有尽有\r
	\r
6️⃣ AI助手加持\r
智能写作、内容生成、翻译、代码优化\r
大大提升创作效率\r
	\r
💼 使用场景：\r
- 学生党：课程笔记、学习计划、论文管理\r
- 职场人：项目管理、任务跟踪、会议记录\r
- 创作者：内容规划、灵感收集、作品管理\r
- 团队：知识库、SOP文档、协作空间\r
	\r
🎁 免费版够用吗？\r
个人使用完全免费！功能基本够用，只是团队协作和文件上传有少量限制。\r
	\r
🔗 访问地址：https://notion.so/\r
	\r
💡 小贴士：\r
- 国内访问可能需要科学上网\r
- 可以先从模板开始，快速上手\r
- 建议先熟悉块编辑和数据库功能\r
	\r
用了Notion之后，真的会爱上这种All-in-One的工作方式！强烈推荐给所有需要高效管理信息和任务的朋友！\r
	\r
Notion #笔记软件 #效率工具 #工作管理 #团队协作 #allinone练习 #Notion #笔记软件 #效率工具 #工作管理 #团队协作\r
\r
\r
\r
\r
\r
\r
\r
\r
\r
\r
`,O=`---\r
title: "星露谷养殖攻略 | 🐥动物合集"\r
date: \r
cover: "/images/02.jpg"\r
ratio: 0.75\r
---\r
🌻玛妮的牧场位于煤矿森林的东北部，靠近鹈鹕镇的西南入口。牧场也是玛妮以及她的侄女贾斯和侄子谢恩的家。\r
🌻玛妮的营业时间是每天上午9:00至下午4:00（除了每周一、每周二、秋季的18日和冬季的18日之外）。\r
🌻玛妮的牧场从上午9:00到下午6:00一直都是可以进入的，即使玛妮已停止营业。\r
💕学会了动物目录后，即使玛妮不在，也可以使用商店。\r
‼️注意：在你升级或者建造建筑期间，玛妮不会出售动物给你。\r
在支付之前，你可以看到将收到什么颜色的动物。当玛妮要求选择你的动物将存放在哪栋建筑时，屏幕上方的备注会显示该动物是哪种颜色。 这时取消购买会返回到购买菜单。`,R=`---\r
title: "🎉独立开发六个月，1w+用户达成啦！💫"\r
date: \r
cover: "/images/03.jpg"\r
ratio: 0.75\r
---\r
从0到10000，花了足足6个月的时间，虽然并不多，但也算一个小小的里程碑\r
	\r
作为一个从运营转的产品，一直对各种产品非常感兴趣，cursor推出的第一时间就深度使用了，到现在还清楚记得一天写出个人网站对我造成的震撼\r
于是，没有技术背景也设计背景，带着自己对产品理念和审美的一些思考\r
开始用业余时间拉上我的员工 Claude 和 GPT一起研究交互、UI、上架、推广\r
	\r
自己从一开始完全看不懂代码，到后来能读懂逻辑，也算是成了一名所谓的 Vibe Coder，这过程中真的学到了非常多东西\r
	\r
总结一些不算经验的Vibe coding感悟\r
🌟 非常推荐刚入门的独立开发者先做满足自身需求的产品，只有充分了解需求和使用场景，才能更好服务用户，接下来就是努力找到和你共鸣的那群人\r
	\r
🌟 挖掘极度垂直、未被满足的需求，例如各种生活场景，甚至是同类App中的差评\r
	\r
🌟 在小红书推广，产品的设计审美是最重要的\r
	\r
🌟 不断提升自己描述需求的能力，不要指望几句模糊的对话做出一个产品\r
	\r
🌟 确保知道AI打算做什么，先让他输出想法和方案，必要时进行纠错或优化后再开始改动代码\r
	\r
🌟 必要时手动提供最新的开发文档或开启联网搜索\r
	\r
🌟 每个模型都有不同的上下文大小限制，避免上下文过长；新建窗口后要让他重新充分了解项目现状\r
	\r
🌟 不用看各种教程，选择一个合适的模型马上实践，行动力是第一生产力\r
	\r
两个App并不完美，但还是感谢愿意支持的所有用户，未来会继续努力优化和迭代，也会继续创造更多有趣好用的产品\r
最后也要颁发最佳员工奖给Claude 和 GPT，毕竟愿意陪老板加班到凌晨\r
	\r
如果你感兴趣的话\r
⬇️\r
🌟Do it！是一款简洁漂亮的任务管理App，用负担最小的方式，解放杂乱的思绪，帮助你专注真正重要的事项\r
🌟Tracck！是一款专为内容创作者、自媒体博主打造的商单管理、排期工具；\r
	\r
\r
\r
\r
\r
\r
\r
`,F=`---\r
title: "用Gemini3做了个裸辞陪伴APP，重建生活秩序"\r
date: "2025-11-28"\r
cover: "/images/04.jpg"\r
ratio: 0.75\r
---\r
最近burnout后裸辞的小伙伴变多了，但离开原有轨道后，往往会有焦虑，而且需要构建新的生活秩序；【记录】往往是是改变的第一步，试试用Gemini3做了一个html网页版，主要包含四个功能：\r
	\r
📅今日 (Today): 建立微习惯（喝水、读书、运动），而不是宏大的工作目标。\r
	\r
🎨规划 (Plan): 看板式的任务管理，区分“求职”、“提升”和“生活”。\r
	\r
🥲情绪 (Mood): 记录心情曲线，提供“焦虑急救包”（呼吸练习）。\r
	\r
🌾生存 (Runway): 极简的财务跑道计算，理性面对现实，减少未知的恐惧。\r
\r
\r
\r
\r
\r
\r
\r
\r
`,B=`---\r
title: "ai现在已经发展到这种程度了吗？！"\r
date: "2025-11-28"\r
cover: "/images/05.jpg"\r
ratio: 0.75\r
---\r
依旧nanobanana pro 制作，很多人反应说豆包做的太过于粗糙，毕竟免费的不能要求太多，最近会给大家找个好用的网站\r
\r
\r
\r
\r
`,G=`---\r
title: "Figma还是替代不了Axure"\r
date: "2025-11-28"\r
cover: "/images/06.jpg"\r
ratio: 0.75\r
---\r
最近学习使用figma，画的图是精致了，但是对于产品经理需要快速构建原型，然后找客户对需求再迭代这一套流程还是不适应。同样一个原型，axure一小时工作量用figma要一天，而且因为要做好反而浪费了很多需求分析的时间，得不偿失。\r
我最近尝试用figma，效率低了很多，项目经理也有抱怨，最后还是改回axure，还是要做自己擅长的事情，UI的事情还是要留给UI去做。\r
`,T=`---\r
title: "MiniMax 开放平台前来报道"\r
date: "2025-11-28"\r
cover: "/images/06.jpg"\r
ratio: 0.75\r
---\r
🚀 MiniMax 开放平台上线小红书啦！\r
大家好，我们正式开张营业！🎉\r
这里是 MiniMax 开放平台官方账号\r
负责为大家带来：\r
✨ 新模型第一手资讯\r
✨ 技术能力解读\r
✨ 神奇又好玩的 AI 玩法\r
✨ 以及不定期掉落的开发者福利（重点！）\r
💡「Ask Me Anything」\r
关于模型能力、API 接入、开发工具、未来计划\r
甚至“我们是不是靠咖啡续命”——\r
尽管问！我们真的会回（非常认真那种）。\r
📢 评论区见！ 赶紧来做第一个和我们互动的小红薯吧！👇`,E=M("blog",{state:()=>({allPosts:[],isLoaded:!1}),actions:{initPosts(){if(this.isLoaded)return;console.log("Pinia: 正在从文件系统读取 Markdown...");const l=Object.assign({"/src/posts/01.md":C,"/src/posts/02.md":O,"/src/posts/03.md":R,"/src/posts/04.md":F,"/src/posts/05.md":B,"/src/posts/06.md":G,"/src/posts/07.md":T}),r=[];let s=0;for(const c in l){const e=l[c];try{const o=D(e).attributes;r.push({id:s++,title:o.title||"无标题",img:o.cover||"https://picsum.photos/400/300",aspectRatio:o.ratio||.75,user:o.user||"lcj",avatar:o.avatar||"https://api.dicebear.com/7.x/miniavs/svg?seed=admin",likes:o.likes||0,date:o.date||"2025-01-01",isLiked:!1,filePath:c})}catch{console.error("解析失败",c)}}this.allPosts=r.sort((c,e)=>new Date(e.date)-new Date(c.date)),this.loadLikesFromStorage(),this.isLoaded=!0},loadLikesFromStorage(){try{const l=JSON.parse(localStorage.getItem("xhs_likes_pinia")||"{}");this.allPosts.forEach(r=>{l[r.id]&&(r.isLiked=!0)})}catch{}},toggleLike(l){const r=this.allPosts.find(s=>s.id===l);if(r){r.isLiked=!r.isLiked,r.isLiked?r.likes++:r.likes--;try{const s=JSON.parse(localStorage.getItem("xhs_likes_pinia")||"{}");r.isLiked?s[r.id]=!0:delete s[r.id],localStorage.setItem("xhs_likes_pinia",JSON.stringify(s))}catch{}}}}}),V={class:"waterfall-box"},$=["onClick"],J=["src","alt"],U={class:"card-content"},z={class:"title"},W={class:"footer"},q={class:"user"},K=["src"],Z={class:"username"},H={key:0,class:"pagination fade-in-up"},Q=["disabled"],X={class:"page-info"},Y=["disabled"],nn={key:1,class:"empty-tip glass-card"},h=12,rn={__name:"index",setup(l){const r=j(),s=E(),c=k(null),e=k(1);I(()=>{s.initPosts()});const d=m(()=>s.allPosts),o=[.75,1,.75,1.33,.6,.75,1],S=m(()=>{const i=(e.value-1)*h,t=i+h;return d.value.slice(i,t).map((g,f)=>{const L=g.aspectRatio||o[f%o.length];return{...g,visualRatio:L}})}),u=m(()=>Math.ceil(d.value.length/h)),b=i=>{i<1||i>u.value||(e.value=i,window.scrollTo({top:0,behavior:"smooth"}))},A=i=>{r.push({path:"/post",query:{path:i.filePath}})};return(i,t)=>(_(),p(P,null,[t[4]||(t[4]=n("div",{class:"blog-bg-layer"},null,-1)),n("div",{class:"xhs-container",ref_key:"containerRef",ref:c},[t[3]||(t[3]=n("div",{class:"blog-header fade-in-up"},[n("h2",{class:"handwritten"},"My Stories"),n("p",{class:"subtitle"},"记录生活，探索代码")],-1)),n("div",V,[(_(!0),p(P,null,w(S.value,(a,g)=>(_(),p("div",{key:a.id,class:"card glass-card pop-in",style:x({animationDelay:`${g*.05}s`}),onClick:f=>A(a)},[n("div",{class:"card-img-wrapper",style:x({paddingBottom:1/a.visualRatio*100+"%"})},[n("img",{src:a.img,loading:"lazy",alt:a.title},null,8,J),t[2]||(t[2]=n("div",{class:"img-overlay"},[n("div",{class:"read-btn"},[n("span",null,"looklook")])],-1))],4),n("div",U,[n("div",z,v(a.title),1),n("div",W,[n("div",q,[n("img",{src:a.avatar,class:"avatar"},null,8,K),n("span",Z,v(a.user),1)])])])],12,$))),128))]),u.value>1?(_(),p("div",H,[n("button",{class:"page-btn glass-btn",disabled:e.value===1,onClick:t[0]||(t[0]=a=>b(e.value-1))},"← Prev",8,Q),n("span",X,v(e.value)+" / "+v(u.value),1),n("button",{class:"page-btn glass-btn",disabled:e.value===u.value,onClick:t[1]||(t[1]=a=>b(e.value+1))},"Next →",8,Y)])):y("",!0),d.value.length===0?(_(),p("div",nn," 🍃 还没有文章，快去 src/posts/ 下新建一个 md 文件吧！ ")):y("",!0)],512)],64))}},en=N(rn,[["__scopeId","data-v-f40bd3df"]]);export{en as default};
